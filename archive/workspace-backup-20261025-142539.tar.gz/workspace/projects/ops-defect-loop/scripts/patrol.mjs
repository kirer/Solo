#!/usr/bin/env node
/**
 * ops-defect-loop 只读巡检脚本（运行记录巡检）
 *
 * 数据源：workspace/company.sqlite（含未 checkpoint 的 company.sqlite-wal）
 *        —— 用只读连接打开，SQLite 会自动合并 WAL，读到最新数据。
 *        —— 禁止用 `cp` 拷贝主库单文件来分析：那样会丢掉 -wal 里的最新记录。
 *
 * 用法：
 *   node scripts/patrol.mjs                 # 无参数即可运行（默认库）
 *   node scripts/patrol.mjs --db <path>     # 覆盖数据源路径
 *   node scripts/patrol.mjs --quiet         # 只写文件，不打印摘要
 *
 * 产出：
 *   out/patrol-<YYYYMMDD-HHmm>.jsonl   机器可读，每条一行 {at, rule, grade, ...证据}
 *   out/patrol-<YYYYMMDD-HHmm>.md      人可读，按 P0-P3 分组，含证据行
 *
 * 退出码：
 *   0 = 无发现
 *   1 = 有发现（P0-P3 任意一条）
 *   2 = 数据源打不开
 *
 * 铁律：只读。本脚本只发 SELECT，绝不 UPDATE/INSERT/DELETE。
 *
 * ── 定期运行方式（cron）──────────────────────────────────────────
 *   # 每 30 分钟跑一次，有发现时把摘要写进 logs/patrol-cron.log
 *   crontab -e 后加入（单行）：
 *
 *   *​/30 * * * * cd /Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop && /usr/bin/env node scripts/patrol.mjs --quiet >> logs/patrol-cron.log 2>&1
 *
 *   # 若用 launchd（macOS 推荐），见同目录 patrol.cron.md 给出的 plist。
 *   # 想「有发现才告警」，用退出码判断：node scripts/patrol.mjs --quiet || echo "有发现"
 * ────────────────────────────────────────────────────────────────
 */
import { DatabaseSync } from "node:sqlite";
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const HERE = dirname(fileURLToPath(import.meta.url)); // .../ops-defect-loop/scripts
const PROJECT_DIR = resolve(HERE, ".."); // .../ops-defect-loop
// 默认数据源：workspace/company.sqlite（PROJECT_DIR/../../../company.sqlite）
const DEFAULT_DB = resolve(PROJECT_DIR, "..", "..", "company.sqlite");

// ── 参数解析 ────────────────────────────────────────────────────
const argv = process.argv.slice(2);
let DB_PATH = DEFAULT_DB;
const QUIET = argv.includes("--quiet");
const dbFlag = argv.indexOf("--db");
if (dbFlag >= 0) {
	const value = argv[dbFlag + 1];
	if (value === undefined) {
		console.error("[patrol] --db 需要一个路径参数");
		process.exit(2);
	}
	DB_PATH = resolve(value);
}

// 与 src/runtime/recover.ts 的超期口径保持一致（不另立标准）
const TOOL_OVERDUE_MS = 300_000; // pi.tool：300s
const GEN_OVERDUE_MS = 600_000; // 其余（pi.generation 等）：600s
const NOW = Date.now();

/** 非终态集合：只有这些状态的任务还可能继续推进。 */
const LIVE_STATES = new Set(["pending", "running", "waiting", "completing"]);

// ── 打开数据源（只读）───────────────────────────────────────────
let db;
try {
	db = new DatabaseSync(DB_PATH, { readOnly: true });
	db.exec("PRAGMA busy_timeout = 5000");
	// 读一次验证可通（连接是惰性的，打不开要在这里暴露）
	db.prepare("SELECT 1 AS ok").get();
} catch (error) {
	console.error(`[patrol] 无法打开数据源 ${DB_PATH}：${error?.message ?? error}`);
	process.exit(2);
}

const findings = [];
const unreadable = []; // 读表失败要显式记录，不静默吞掉

/**
 * 安全的 SELECT。失败时记进 unreadable 并返回 fallback，绝不静默。
 * @param {string} table  用于报告「哪张表不可读」
 * @param {string} sql
 * @param {unknown[]} params
 */
function select(table, sql, params = [], fallback = []) {
	try {
		return db.prepare(sql).all(...params);
	} catch (error) {
		unreadable.push({ table, error: String(error?.message ?? error) });
		return fallback;
	}
}

/**
 * JSON 列解析。库里的 kind/status 存在**双重编码**（值形如 `"pi.tool"` 带引号），
 * record 列是正常的 JSON 文本。统一在这里剥一次。
 */
function decodeMaybeJson(value) {
	if (typeof value !== "string") return value;
	let current = value;
	for (let i = 0; i < 2; i += 1) {
		if (typeof current !== "string") break; // 上一轮已解成对象，停止继续剥
		if (!(current.startsWith('"') || current.startsWith("{") || current.startsWith("["))) break;
		try {
			current = JSON.parse(current);
		} catch {
			return current;
		}
	}
	return current;
}

function parseRecord(raw) {
	const decoded = decodeMaybeJson(raw);
	if (decoded && typeof decoded === "object") return decoded;
	try {
		return JSON.parse(raw);
	} catch {
		return {};
	}
}

/**
 * 读一个文档的**完整内容**（OPS-20261025-01）。
 *
 * 为什么不能只读 `documents.record`：那一列只存**元数据头**
 * （`{id, kind, scope, createdAt}`），文档真正的业务内容在 `document_revisions`
 * 表里——首条是 `base`，后续是一串 `delta`。
 *
 * 第一版规则（以及 OPS-20261025-01 的误报）就是因为直接读 `documents.record`
 * 找 `items`，永远找不到 → 把健康文档判成「结构损坏」。
 * 这与 OPS-20261025-03（读错列导致恒 0 条）是同一类错误：**读错了数据源**。
 *
 * delta 形如 JSON-patch 的极简版，本库只用到两种：
 * - `["s", path, value]`                   —— 把 path 处设为 value
 * - `["p", path, index, deleteCount, vals]` —— 在 path 指向的数组上 splice
 * 遇到不认识的形状就抛错，由调用方降级为「读不出」而不是静默算成空文档。
 */
function readDocumentContent(documentId) {
	const rows = select(
		"document_revisions",
		`SELECT seq, kind, content FROM document_revisions
		 WHERE document_id = ? ORDER BY seq ASC`,
		[documentId],
	);
	if (rows.length === 0) return undefined;

	let doc;
	for (const row of rows) {
		let payload;
		try {
			payload = JSON.parse(row.content);
		} catch {
			throw new Error(`document_revisions.document_id=${documentId} seq=${row.seq} 内容不是合法 JSON`);
		}
		if (row.kind === "base") {
			doc = payload;
			continue;
		}
		if (doc === undefined) throw new Error(`document_revisions.document_id=${documentId} 缺少 base`);
		applyDelta(doc, payload);
	}
	return doc;
}

/** 在一个已解析的文档上应用一条 delta（原地修改）。 */
function applyDelta(doc, ops) {
	if (!Array.isArray(ops)) throw new Error("delta 不是数组");
	for (const op of ops) {
		if (!Array.isArray(op) || op.length === 0) throw new Error("delta 操作形状不认识");
		const [verb, path, ...rest] = op;
		if (!Array.isArray(path)) throw new Error("delta 操作的 path 不是数组");
		let cursor = doc;
		for (const segment of path.slice(0, -1)) {
			if (cursor === null || typeof cursor !== "object") throw new Error("delta path 越界");
			cursor = cursor[segment];
		}
		const last = path[path.length - 1];
		if (cursor === null || typeof cursor !== "object") throw new Error("delta path 越界");
		if (verb === "s") {
			cursor[last] = rest[0];
		} else if (verb === "p") {
			const [index, deleteCount, values] = rest;
			if (!Array.isArray(cursor[last])) throw new Error("delta p 操作的目标不是数组");
			cursor[last].splice(index, deleteCount, ...(Array.isArray(values) ? values : []));
		} else {
			throw new Error(`不认识的 delta 操作：${String(verb)}`);
		}
	}
}

/** 统一 push：保证每条都有 at / rule / grade / evidence。 */
function push(finding) {
	findings.push({
		at: new Date(NOW).toISOString(),
		rule: finding.rule,
		grade: finding.grade,
		taskId: finding.taskId ?? null,
		detail: finding.detail,
		evidence: finding.evidence,
		...finding.extra,
	});
}

// ── a) task-blocked：反复崩溃被暂停 → P1 ────────────────────────
// 重要：tasks.status 的 CHECK 约束**不允许 'blocked'**（只允许
// pending/running/waiting/sleeping/completing/terminal），
// blocked 是 record.state.status 层面的逻辑状态。
// 因此这里不能用 `WHERE status='blocked'`（那样恒为 0 条，是无效规则）。
// 口径与 src/runtime/recover.ts 的 case "blocked" 保持一致。
const blockedTasks = select(
	"tasks",
	`SELECT id, conversation_id, kind, status, record FROM tasks
	 WHERE json_extract(record, '$.state.status') = 'blocked'`,
);
for (const task of blockedTasks) {
	const record = parseRecord(task.record);
	const state = record?.state ?? {};
	const reason = state?.reason ?? state?.blockedReason ?? "(未记录原因)";
	push({
		rule: "task-blocked",
		grade: "P1",
		taskId: String(task.id),
		detail: `任务 ${task.id}（${decodeMaybeJson(task.kind)}）处于 blocked，疑似反复崩溃被暂停（reason=${reason}）`,
		evidence: `tasks.id=${task.id} column.status=${task.status} state.status=blocked kind=${decodeMaybeJson(task.kind)} reason=${reason}`,
		extra: { conversationId: task.conversation_id },
	});
}

// ── b/c) waiting 类：waiting-on-dead(P1) / waiting-no-target(P2) ─
// 子任务的「活」同样要看 record.state.status，不是 tasks.status 列的取值。
const liveRows = select(
	"tasks",
	`SELECT id, status, record FROM tasks WHERE status IN ('pending','running','waiting','completing')`,
);
const liveIds = new Set(
	liveRows
		.filter((row) => {
			const stateStatus = parseRecord(row.record)?.state?.status;
			// state 层面已 blocked 的，不算活着（它不会再推进）
			return stateStatus !== "blocked";
		})
		.map((row) => String(row.id)),
);

const waitingTasks = select(
	"tasks",
	`SELECT id, conversation_id, kind, status, record FROM tasks WHERE status = 'waiting'`,
);
for (const task of waitingTasks) {
	const record = parseRecord(task.record);
	const state = record?.state ?? {};
	// 口径同 recover.ts：waiting 的等待目标是 state.on
	const rawOn = state?.on ?? record?.on ?? state?.checkpoint?.on ?? null;
	const on = Array.isArray(rawOn) ? rawOn.map(String) : [];

	if (on.length === 0) {
		// c) waiting 但没有等待目标 → 结构异常
		push({
			rule: "waiting-no-target",
			grade: "P2",
			taskId: String(task.id),
			detail: `任务 ${task.id} 状态为 waiting，但 record.on 为空（无等待目标）`,
			evidence: `tasks.id=${task.id} status=waiting kind=${decodeMaybeJson(task.kind)} record.on=[]`,
			extra: { conversationId: task.conversation_id },
		});
		continue;
	}

	// b) 等待的子任务是否还活着
	const aliveChildren = on.filter((id) => liveIds.has(id));
	if (aliveChildren.length === 0) {
		push({
			rule: "waiting-on-dead",
			grade: "P1",
			taskId: String(task.id),
			detail: `任务 ${task.id} 在等 [${on.join(",")}]，但这些子任务已全部离开非终态（或已不存在），父任务不会再被唤醒`,
			evidence: `tasks.id=${task.id} status=waiting on=[${on.join(",")}] alive=[] kind=${decodeMaybeJson(task.kind)}`,
			extra: { conversationId: task.conversation_id },
		});
	}
}

// ── d) task-overdue：running 超过阈值 → P2 ──────────────────────
const runningTasks = select(
	"tasks",
	`SELECT id, conversation_id, kind, status, record FROM tasks WHERE status = 'running'`,
);
for (const task of runningTasks) {
	const record = parseRecord(task.record);
	const startedAt = record?.startedAt;
	if (typeof startedAt !== "number") continue;
	const kind = decodeMaybeJson(task.kind);
	const limit = kind === "pi.tool" ? TOOL_OVERDUE_MS : GEN_OVERDUE_MS;
	const age = NOW - startedAt;
	if (age >= limit) {
		push({
			rule: "task-overdue",
			grade: "P2",
			taskId: String(task.id),
			detail: `任务 ${task.id}（${kind}）按库里 startedAt 计算已 ${Math.round(age / 1000)}s，超过阈值 ${limit / 1000}s。疑似超期，可能为上个进程遗留（巡检是外部进程，拿不到运行时 PROCESS_STARTED_AT，无法区分是否本进程启动）`,
			evidence: `tasks.id=${task.id} status=running kind=${kind} startedAt=${startedAt} age=${Math.round(age / 1000)}s limit=${limit / 1000}s`,
			extra: { conversationId: task.conversation_id },
		});
	}
}

// ── e) watchdog-giveup(P1) / drain(P2)：entries 里的 app.alert ──
const alertRows = select(
	"entries",
	`SELECT id, conversation_id, record FROM entries
	 WHERE json_extract(record, '$.kind') = 'app.alert'`,
);
for (const entry of alertRows) {
	const record = parseRecord(entry.record);
	const data = record?.data ?? {};
	if (data?.giveUp === true) {
		push({
			rule: "watchdog-giveup",
			grade: "P1",
			taskId: data.taskId != null ? String(data.taskId) : null,
			detail: `看门狗已放弃自愈：${String(data.text ?? "(无文案)")}`,
			evidence: `entries.id=${entry.id} kind=app.alert giveUp=true action=${data.action ?? "-"} reason=${data.reason ?? "-"} attempt=${data.attempt ?? "-"}`,
			extra: { conversationId: entry.conversation_id },
		});
	} else if (data?.action === "drain") {
		push({
			rule: "watchdog-drain",
			grade: "P2",
			taskId: data.taskId != null ? String(data.taskId) : null,
			detail: `看门狗执行 drain（队列积压被排空）：${String(data.text ?? "(无文案)")}`,
			evidence: `entries.id=${entry.id} kind=app.alert action=drain reason=${data.reason ?? "-"}`,
			extra: { conversationId: entry.conversation_id },
		});
	}
}

// ── f) submission-stale：queued / unanswered → P2 ───────────────
const staleSubmissions = select(
	"submissions",
	`SELECT id, conversation_id, status FROM submissions WHERE status IN ('queued','unanswered')`,
);
for (const submission of staleSubmissions) {
	push({
		rule: "submission-stale",
		grade: "P2",
		taskId: null,
		detail: `提交 ${submission.id} 停留在 ${submission.status}，未被结算`,
		evidence: `submissions.id=${submission.id} status=${submission.status} conversationId=${submission.conversation_id}`,
		extra: { conversationId: submission.conversation_id },
	});
}

// ── g) escalation-pending：app.pending 文档的 items 中 answer 未填 → P3 ──
// 注意：kind 列是双重编码，用两种写法都试，避免因编码差异漏检。
//
// OPS-20261025-01：**内容不在 documents.record 里**。那一列只有元数据头，
// 真正的 items 在 document_revisions 的 base + delta 链里。直接读 record
// 会把每一条健康文档都判成「没有 items」，造出恒定的 P3 误报（已在真实库
// id=137 上复现：record 只有 {id,kind,scope,createdAt}，回放后实际有 11 条 items）。
const pendingDocs = select(
	"documents",
	`SELECT id, kind, owner_id, record FROM documents
	 WHERE kind IN ('pending', '"pending"', 'app.pending', '"app.pending"')
	   AND retired_at IS NULL`,
);
let pendingDocSeen = 0;
for (const doc of pendingDocs) {
	let content;
	try {
		content = readDocumentContent(doc.id);
	} catch (error) {
		// 回放失败是**真的读不出**，不能静默当成空文档；也不算「无发现」。
		pendingDocSeen += 1;
		push({
			rule: "escalation-doc-unreadable",
			grade: "P3",
			taskId: null,
			detail: `待决文档 ${doc.id} 内容无法回放（delta 链损坏？），本轮无法判断有无未决问题`,
			evidence: `documents.id=${doc.id} kind=${decodeMaybeJson(doc.kind)} error=${String(error?.message ?? error)}`,
		});
		continue;
	}
	if (content === undefined) {
		// 文档头在、但一条 revision 都没有：这是真正的结构异常（正常写入至少会有 base）。
		pendingDocSeen += 1;
		push({
			rule: "escalation-doc-malformed",
			grade: "P3",
			taskId: null,
			detail: `待决文档 ${doc.id} 存在但没有任何 revision（不符合 PendingDoc 写入约定）`,
			evidence: `documents.id=${doc.id} kind=${decodeMaybeJson(doc.kind)} document_revisions=0`,
		});
		continue;
	}
	const items = Array.isArray(content?.items) ? content.items : null;
	if (items === null) {
		// 回放缓成了对象但没有 items：真的是结构不对（PendingDoc.initial() 是 { items: [] }）。
		pendingDocSeen += 1;
		push({
			rule: "escalation-doc-malformed",
			grade: "P3",
			taskId: null,
			detail: `待决文档 ${doc.id} 回放后没有 items 字段（PendingDoc 约定应是 { items: [] }）`,
			evidence: `documents.id=${doc.id} kind=${decodeMaybeJson(doc.kind)} keys=[${Object.keys(content ?? {}).join(",")}]`,
		});
		continue;
	}
	for (const item of items) {
		if (item?.answer !== undefined && item?.answer !== null && item?.answer !== "") continue;
		push({
			rule: "escalation-pending",
			grade: "P3",
			taskId: null,
			detail: `待决问题 [${item?.key ?? "-"}] 来自 ${item?.from ?? "-"}：${String(item?.question ?? "").slice(0, 120)}`,
			evidence: `documents.id=${doc.id} kind=${decodeMaybeJson(doc.kind)} key=${item?.key ?? "-"} answer=未填`,
		});
	}
}

// ── 读表失败必须出现在输出里 ────────────────────────────────────
for (const failure of unreadable) {
	push({
		rule: "table-unreadable",
		grade: "P2",
		taskId: null,
		detail: `该表不可读：${failure.table}（${failure.error}）`,
		evidence: `table=${failure.table} error=${failure.error}`,
	});
}

// ── 输出 ────────────────────────────────────────────────────────
const pad = (n) => String(n).padStart(2, "0");
const d = new Date(NOW);
const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}`;
const outDir = join(PROJECT_DIR, "out");
mkdirSync(outDir, { recursive: true });

const jsonlPath = join(outDir, `patrol-${stamp}.jsonl`);
writeFileSync(jsonlPath, findings.map((f) => JSON.stringify(f)).join("\n") + (findings.length ? "\n" : ""), "utf8");

const byGrade = (grade) => findings.filter((f) => f.grade === grade);
const counts = { P0: byGrade("P0").length, P1: byGrade("P1").length, P2: byGrade("P2").length, P3: byGrade("P3").length };

const mdLines = [
	`# 运行记录巡检结果`,
	"",
	`- 运行时间：${d.toISOString()}`,
	`- 数据源：${DB_PATH}（只读连接，已合并 -wal）`,
	`- 总发现：${findings.length} 条（P0 ${counts.P0} / P1 ${counts.P1} / P2 ${counts.P2} / P3 ${counts.P3}）`,
	"",
];
if (findings.length === 0) {
	mdLines.push("本轮无发现。", "");
} else {
	for (const grade of ["P0", "P1", "P2", "P3"]) {
		const rows = byGrade(grade);
		if (rows.length === 0) continue;
		mdLines.push(`## ${grade}（${rows.length} 条）`, "");
		for (const f of rows) {
			const idPart = f.taskId ? ` · taskId=${f.taskId}` : "";
			mdLines.push(`- \`${f.rule}\`${idPart} — ${f.detail}`);
			mdLines.push(`  - 证据：\`${f.evidence}\``);
		}
		mdLines.push("");
	}
}
if (unreadable.length > 0) {
	mdLines.push("## 不可读的表", "");
	for (const u of unreadable) mdLines.push(`- 该表不可读：\`${u.table}\` — ${u.error}`);
	mdLines.push("");
}
const mdPath = join(outDir, `patrol-${stamp}.md`);
writeFileSync(mdPath, mdLines.join("\n"), "utf8");

if (!QUIET) {
	console.log(`[patrol] 数据源：${DB_PATH}`);
	console.log(`[patrol] 总发现 ${findings.length} 条 → P0 ${counts.P0} / P1 ${counts.P1} / P2 ${counts.P2} / P3 ${counts.P3}`);
	for (const f of findings) {
		console.log(`  - [${f.grade}] ${f.rule}${f.taskId ? ` taskId=${f.taskId}` : ""} :: ${f.detail}`);
		console.log(`      证据: ${f.evidence}`);
	}
	if (unreadable.length > 0) {
		console.log(`[patrol] 警告：${unreadable.length} 张表不可读`);
		for (const u of unreadable) console.log(`  - 该表不可读：${u.table} :: ${u.error}`);
	}
	console.log(`[patrol] JSONL → ${jsonlPath}`);
	console.log(`[patrol] MD    → ${mdPath}`);
}

db.close();
process.exit(findings.length > 0 ? 1 : 0);
