# 巡检定期执行配置

目标：让 `scripts/patrol.mjs` 成为**持续动作**，不是一次性手工运行。

- 脚本：`/Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop/scripts/patrol.mjs`
- 数据源：`/Users/kirer/projects/ai-company/workspace/company.sqlite`（只读连接，自动合并 `-wal`）
- 退出码：`0` 无发现 / `1` 有发现 / `2` 数据源打不开
- node 绝对路径：`/opt/homebrew/bin/node`（**必须用绝对路径**：cron/launchd 的 PATH 默认不含 homebrew，用 `node` 会 `command not found`）

---

## 方案 A：crontab（最简）

`crontab -e` 后加入下面三行（每 30 分钟一次；有发现时摘要进 patrol-cron.log）：

```cron
# ops-defect-loop 运行记录巡检：每 30 分钟一次
SHELL=/bin/bash
*/30 * * * * cd /Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop && mkdir -p logs && /opt/homebrew/bin/node scripts/patrol.mjs --quiet >> logs/patrol-cron.log 2>&1; code=$?; ts=$(date -u +%FT%TZ); echo "[$ts] exit=$code" >> logs/patrol-exit.log
```

要点：
- `cd` 到项目目录再跑，保证 `out/` 相对路径落在项目内。
- `--quiet` 让脚本只写文件、不刷屏；`>> logs/patrol-cron.log` 保留摘要。
- 单独记录退出码到 `patrol-exit.log`，便于后续做「有发现则告警」。
- **必须先把 `$?` 存进变量再取时间戳**：`echo "[$(date)] exit=$?"` 会被命令替换重置成 `date` 的退出码（恒为 0），从而把「有发现(1)」误记成「无发现(0)」。这个坑已在实测中复现并修正。

如果想让 cron 在**有发现时**额外发通知，可改成：

```cron
*/30 * * * * cd /Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop && mkdir -p logs && /opt/homebrew/bin/node scripts/patrol.mjs --quiet >> logs/patrol-cron.log 2>&1; code=$?; if [ "$code" -eq 1 ]; then ts=$(date -u +%FT%TZ); echo "[$ts] ops-defect-loop 巡检有发现，见 out/ 最新 patrol-*.md" >> logs/patrol-alert.log; fi
```

> 注意 macOS 上 cron 需要「完全磁盘访问权限」才能稳定运行；若发现 cron 不触发，优先用方案 B。

---

## 方案 B：launchd（macOS 推荐）

保存为 `~/Library/LaunchAgents/com.aicompany.ops-patrol.plist`：

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.aicompany.ops-patrol</string>

  <key>ProgramArguments</key>
  <array>
    <string>/opt/homebrew/bin/node</string>
    <string>/Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop/scripts/patrol.mjs</string>
    <string>--quiet</string>
  </array>

  <key>WorkingDirectory</key>
  <string>/Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop</string>

  <!-- 每 1800 秒（30 分钟）跑一次 -->
  <key>StartInterval</key>
  <integer>1800</integer>

  <!-- 加载时先跑一次，便于立刻验证 -->
  <key>RunAtLoad</key>
  <true/>

  <!-- 不要因为退出码 1（有发现）就被判为异常失败 -->
  <key>StandardOutPath</key>
  <string>/Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop/logs/patrol-launchd.log</string>
  <key>StandardErrorPath</key>
  <string>/Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop/logs/patrol-launchd.err.log</string>

  <key>EnvironmentVariables</key>
  <dict>
    <key>PATH</key>
    <string>/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
  </dict>
</dict>
</plist>
```

启用：

```bash
mkdir -p /Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop/logs
cp com.aicompany.ops-patrol.plist ~/Library/LaunchAgents/
launchctl load  ~/Library/LaunchAgents/com.aicompany.ops-patrol.plist
launchctl list | grep ops-patrol          # 确认已注册
tail -f /Users/kirer/projects/ai-company/workspace/projects/ops-defect-loop/logs/patrol-launchd.log
```

停用：

```bash
launchctl unload ~/Library/LaunchAgents/com.aicompany.ops-patrol.plist
```

---

## 验证建议

装载后应能看到：

1. `out/` 下每 30 分钟新增一对 `patrol-<YYYYMMDD-HHmm>.{jsonl,md}`；
2. `logs/patrol-launchd.log`（或 `logs/patrol-cron.log`）有对应运行记录；
3. `launchctl list | grep ops-patrol` 的最后一列是退出码（0 或 1 都正常，2 表示数据源打不开，需排查）。

> 说明：以上配置由 backend-fix 按真实路径编写，但**尚未在本机安装生效**（安装会改动你的用户级调度配置，属需要你批准的变更）。已在真实环境中验证过的是：`/opt/homebrew/bin/node` 存在、`/usr/bin/crontab` 存在、脚本以绝对路径直接运行可跑通（见 out/ 实际产物）。
