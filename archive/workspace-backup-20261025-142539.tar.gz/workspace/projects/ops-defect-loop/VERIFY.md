write-ok
